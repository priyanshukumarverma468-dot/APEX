# APEX Advanced AI Agent V2 — Starter

Android/Termux-friendly **foundation**, not yet a fully autonomous AI agent. The original ECC ZIPs are preserved in `vendor/`. Nothing from them is automatically executed.

## Start (Termux)
```sh
pkg install python -y
cd APEX_V2_Starter
python app/main.py
```
Visit `http://127.0.0.1:8002/api/health`, `/api/skills`, `/api/content/templates`.

## Included
- Both original ECC archives (unmodified) in `vendor/`
- Indexed ECC skill names in `skills/catalog/ecc_index.json`
- Selected agent, mobile, content and media guides in `skills/curated/`
- Local skill discovery API without third-party dependencies

## Next milestones
1. Review skill licenses and instruction safety before integration.
2. Add a model provider adapter and explicit user approval for write/execute actions.
3. Add GitHub read/write integration with scoped permissions.
4. Add content planning and optional editing/export pipelines.
5. Add APK build runner through a trusted build environment.

Do not commit API keys, access tokens, or private user files.
