"""APEX V2: local, offline-first skill explorer. No untrusted skill is executed."""
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import json, urllib.parse
ROOT=Path(__file__).resolve().parents[1]
CAT=json.loads((ROOT/'skills/catalog/ecc_index.json').read_text())
class Handler(BaseHTTPRequestHandler):
 def do_GET(self):
  path=urllib.parse.urlsplit(self.path).path
  if path=='/api/health': data={'status':'ok','project':'APEX V2','mode':'skill-catalog'}
  elif path=='/api/skills': data={'count':len(CAT['skills']),'skills':CAT['skills']}
  elif path=='/api/content/templates': data={'templates':['shorts-hook','reels-script','thumbnail-brief','caption-hashtags','video-edit-plan']}
  else: self.send_response(404);self.end_headers();return
  body=json.dumps(data,ensure_ascii=False).encode()
  self.send_response(200);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
if __name__=='__main__':
 print('APEX V2 local API: http://127.0.0.1:8002/api/health')
 HTTPServer(('127.0.0.1',8002),Handler).serve_forever()
